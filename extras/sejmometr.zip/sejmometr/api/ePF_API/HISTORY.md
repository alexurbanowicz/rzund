
ePF_API - historia
==================

ePF_API 0.1.1 / 2013.02.05
--------------------------
- zmiana nazwy z eP_API na ePF_API 
- pierwsza "publiczna" edycja:
    * wersja "autoloader" (Paweł Sroka 'Srokap' https://github.com/Srokap)

eP_API 0.1.0 / 2012.12.04
-------------------------
- pierwsza wersja @ GitHub (Daniel Macyszyn 'danielmacyszyn' https://github.com/danielmacyszyn)

[.]