<?php
/*
 * PONIŻEJ WKLEJ SWOJE KLUCZE API. ABY JE UZYSKAĆ, MUSISZ ZAREJETROWAĆ KONTO NA PORTALU http://sejmometr.pl
 * WIĘCEJ INFORMACJI NA http://sejmometr.pl/api
 */

define('eP_API_KEY', 'c40b1edef3fd2ee57c88e8bbb461089e');
define('eP_API_SECRET', '7ae2ce2313843b155422734360cd5090');

/*
 * Jeżeli stałe eP_API_KEY i eP_API_SECRET definiujesz w innym pliku - pamiętaj, aby powyższe definicje były wykomentowane
 */

require_once('classes/ep_Autoloader.php');
$autoloader = new ep_Autoloader();
$autoloader->register();
require_once('classes/ep_API.php');
