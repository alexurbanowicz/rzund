<!DOCTYPE html>
<html>
  <head>
    <title>Bootstrap 101 Template</title>
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <!-- Bootstrap -->
    <link href="css/bootstrap.min.css" rel="stylesheet" media="screen">
  </head>
  <body>
	<?php
	    //  Załącznie biblioteki Sejmometr API		
            require_once('api/ePF_API/ep_API.php');

            $tablicaPoslow = array();
                        
            for($i = 0; $i < 24; $i++){
                $dataset = new ep_Dataset('poslowie');
                $poslowie = $dataset->find_all(20,$i * 20);

                $poslowie = array_filter($poslowie);

                foreach($poslowie as $posel){
                    $tablicaPoslow[] = array(
                        'id' => $posel->data['id'],
                        'imie_pierwsze' => $posel->data['imie_pierwsze'],
                        'imie_drugie' => $posel->data['imie_pierwsze'],
                        'nazwisko' =>  $posel->data['nazwisko'],
                        'plec' =>  $posel->data['plec'],
                        'klub_id' => $posel->data['klub_id'],
                        'data_urodzenia' =>  $posel->data['data_urodzenia'],
                    );
                }
            }
            
            echo count($tablicaPoslow);
            
            $dataset = new ep_Dataset('sejm_kluby');
            $kluby = $dataset->find_all();
            
            $tablicaKlubow = array();
            
            foreach($kluby as $klub){
                $tablicaKlubow[] = array(
                    'id' => $klub->data['id'],
                    'nazwa' => $klub->data['nazwa'],
                );
            }
            
            //var_dump(json_encode($tablicaPoslow));
            //var_dump(json_encode($tablicaKlubow));
            $fp = fopen('poslowie.json', 'w');
            fwrite($fp, json_encode($tablicaPoslow));
            fclose($fp);
            
            $fp = fopen('kluby.json', 'w');
            fwrite($fp, json_encode($tablicaKlubow));
            fclose($fp);
	?>
	
	
     
	
	<script src="http://code.jquery.com/jquery.js"></script>
        <script src="js/bootstrap.min.js"></script>
  </body>
</html>
